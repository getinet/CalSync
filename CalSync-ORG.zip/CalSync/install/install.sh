#!/usr/bin/env bash
set -euo pipefail
REPO="$(cd "$(dirname "$0")/.." && pwd)"
CALSYNC_DIR="$HOME/.calsync"
APP="$CALSYNC_DIR/CalSync.app"
APPBIN="$APP/Contents/MacOS/applet"
PLIST_SRC="$REPO/install/net.beezwax.calsync.plist"
PLIST_DEST="$HOME/Library/LaunchAgents/net.beezwax.calsync.plist"

mkdir -p "$CALSYNC_DIR"

# Build and stage the runnable OUTSIDE ~/Documents so nothing CalSync runs ever
# needs Documents-folder access (avoids that TCC prompt entirely).
"$REPO/build.sh"
cp "$REPO/dist/calsync.js" "$CALSYNC_DIR/calsync.js"

# Compile an app bundle. The app has its own TCC identity, so once you approve its
# Calendar prompt, launchd runs of the same app inherit the grant (a plain osascript
# LaunchAgent cannot — it hangs on the un-grantable background access request).
# NOTE: recompiling changes the app's code signature, so permissions must be
# re-approved after each re-install.
rm -rf "$APP"
osacompile -l JavaScript -o "$APP" "$CALSYNC_DIR/calsync.js"
INFO="$APP/Contents/Info.plist"
PLB=/usr/libexec/PlistBuddy
# Accessory app: no Dock icon, but can still surface the first-run permission prompts.
$PLB -c "Add :LSUIElement bool true" "$INFO" 2>/dev/null || $PLB -c "Set :LSUIElement true" "$INFO"
# REQUIRED usage-description strings — without these, modern macOS silently DENIES the
# calendar/automation access request (status 0, no prompt) instead of asking the user.
$PLB -c "Add :NSCalendarsFullAccessUsageDescription string 'CalSync mirrors your work calendar events to a personal calendar.'" "$INFO" 2>/dev/null \
  || $PLB -c "Set :NSCalendarsFullAccessUsageDescription CalSync mirrors your work calendar events to a personal calendar." "$INFO"
$PLB -c "Add :NSCalendarsUsageDescription string 'CalSync mirrors your work calendar events to a personal calendar.'" "$INFO" 2>/dev/null || true
$PLB -c "Add :NSAppleEventsUsageDescription string 'CalSync creates mirrored events and invitations in Calendar.'" "$INFO" 2>/dev/null || true
# Editing Info.plist invalidates the bundle signature; TCC requires a valid one, so re-sign (ad-hoc).
codesign --force --sign - "$APP"

# Config scaffold on first install (never overwrite an existing config).
if [ ! -f "$CALSYNC_DIR/config.json" ]; then
  cat > "$CALSYNC_DIR/config.json" <<'JSON'
{
  "workCalendarName": "Calendar",
  "workCalendarAccount": "Exchange",
  "dedicatedCalendarName": "CalSync Mirror",
  "personalEmail": "you@example.com",
  "organizerEmail": "you@icloud.com",
  "windowDays": 30,
  "cancelThreshold": 0.25
}
JSON
  echo "Wrote config scaffold to $CALSYNC_DIR/config.json — edit it before relying on scheduled runs."
fi

# Install + (re)load the LaunchAgent (hourly).
mkdir -p "$HOME/Library/LaunchAgents"
sed "s|__APPBIN__|$APPBIN|" "$PLIST_SRC" > "$PLIST_DEST"
launchctl unload "$PLIST_DEST" 2>/dev/null || true
launchctl load "$PLIST_DEST"

echo ""
echo "LaunchAgent net.beezwax.calsync loaded (runs hourly)."
echo ""
echo "ONE-TIME SETUP — grant the app calendar permissions:"
echo "  open \"$APP\""
echo "  → approve the 'access your calendars' and 'control Calendar' prompts."
echo "  (Until you do this once, scheduled runs cannot access the calendar.)"
echo ""
echo "Change cadence: edit StartCalendarInterval in $PLIST_DEST (Minute 0 = top of every hour;"
echo "                add an Hour key or an array of dicts for specific times), then: launchctl unload && load."
echo "Manual dry-run: osascript -l JavaScript $CALSYNC_DIR/calsync.js --dry-run"
echo "Watch log:      tail -f $CALSYNC_DIR/calsync.log"
echo "Stop schedule:  launchctl unload $PLIST_DEST"
