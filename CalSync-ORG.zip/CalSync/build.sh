#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p dist
cat src/lib.js src/adapter.js src/main.js > dist/calsync.js
echo "built dist/calsync.js"
