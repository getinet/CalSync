eval(ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError($('tests/harness.js'), $.NSUTF8StringEncoding, $())));

eq(1 + 1, 2, 'arithmetic works');
ok(true, 'ok() works');
done();
