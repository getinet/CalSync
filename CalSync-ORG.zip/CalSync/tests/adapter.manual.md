# Reader manual verification (EventKit)
Prereq: `CalSync Spike` iCloud calendar with one single + one weekly recurring event. Grant the full-calendar-access prompt on first run.

Probe (from repo root):
    osascript -l JavaScript -e 'eval(ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError($("src/adapter.js"),$.NSUTF8StringEncoding,$()))); JSON.stringify(getWorkInstances("CalSync Spike", new Date(), new Date(Date.now()+30*864e5)), null, 2)'

Expected:
- Weekly event appears as MULTIPLE rows (~4-5), each isRecurring:true with a DISTINCT occurrenceStartIso.
- Single event appears once, isRecurring:false, occurrenceStartIso:null.
- getWorkInstances("No Such Calendar", ...) returns null.
