eval(ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError($('tests/harness.js'), $.NSUTF8StringEncoding, $())));
eval(ObjC.unwrap($.NSString.stringWithContentsOfFileEncodingError($('src/lib.js'), $.NSUTF8StringEncoding, $())));

// encodeMarker
eq(encodeMarker('ABC', null, false), 'x-calsync://ABC', 'single marker');
eq(encodeMarker('ABC', '2026-07-02T15:00:00Z', true), 'x-calsync://ABC/2026-07-02T15:00:00Z', 'recurring marker');

// parseMarker
eq(parseMarker('x-calsync://ABC'), { workUid: 'ABC', occurrenceStartIso: null }, 'parse single');
eq(parseMarker('x-calsync://ABC/2026-07-02T15:00:00Z'), { workUid: 'ABC', occurrenceStartIso: '2026-07-02T15:00:00Z' }, 'parse recurring');
eq(parseMarker('https://example.com'), null, 'non-calsync url -> null');
eq(parseMarker(''), null, 'empty -> null');
eq(parseMarker(null), null, 'null -> null');
eq(parseMarker('x-calsync://%ZZ'), null, 'malformed percent encoding -> null (no throw)');
eq(parseMarker('x-calsync://%'), null, 'lone percent -> null (no throw)');

// round-trip: parse(encode(...)) recovers inputs
eq(parseMarker(encodeMarker('ABC', null, false)), { workUid: 'ABC', occurrenceStartIso: null }, 'round-trip single');
eq(parseMarker(encodeMarker('ABC', '2026-07-02T15:00:00Z', true)), { workUid: 'ABC', occurrenceStartIso: '2026-07-02T15:00:00Z' }, 'round-trip recurring');
eq(parseMarker(encodeMarker('a/b/c', '2026-07-02T15:00:00Z', true)), { workUid: 'a/b/c', occurrenceStartIso: '2026-07-02T15:00:00Z' }, 'round-trip recurring with slashes in uid');

// injective markers: a slash in a single-event uid must not collide with a recurring marker
ok(encodeMarker('a/b', null, false) !== encodeMarker('a', 'b', true), 'no collision: slashed-uid single vs recurring');
eq(parseMarker(encodeMarker('a/b', null, false)), { workUid: 'a/b', occurrenceStartIso: null }, 'slashed uid single round-trips');
eq(parseMarker(encodeMarker('a', 'b', true)), { workUid: 'a', occurrenceStartIso: 'b' }, 'recurring a/b round-trips distinctly');

// isSingleValidAttendee(attendees, personalEmail)
eq(isSingleValidAttendee(['you@example.com'], 'you@example.com'), true, 'exactly one matching attendee');
eq(isSingleValidAttendee(['YOU@Example.com'], 'you@example.com'), true, 'case-insensitive match');
eq(isSingleValidAttendee([' you@example.com '], 'you@example.com'), true, 'trims whitespace');
eq(isSingleValidAttendee([], 'you@example.com'), false, 'zero attendees rejected');
eq(isSingleValidAttendee(['you@example.com', 'boss@work.com'], 'you@example.com'), false, 'more than one rejected');
eq(isSingleValidAttendee(['boss@work.com'], 'you@example.com'), false, 'non-matching rejected');
eq(isSingleValidAttendee(null, 'you@example.com'), false, 'null attendees rejected');
eq(isSingleValidAttendee([''], ''), false, 'empty personalEmail never passes');
eq(isSingleValidAttendee(['you@example.com'], ''), false, 'empty personalEmail rejected even with real attendee');
eq(isSingleValidAttendee(['you@example.com'], undefined), false, 'undefined personalEmail rejected');
eq(isSingleValidAttendee([{ email: 'boss@work.com' }], 'you@example.com'), false, 'non-string attendee fails closed (no throw)');
eq(isSingleValidAttendee([null], 'you@example.com'), false, 'null attendee element fails closed');

// reconcile
var OPTS = { personalEmail: 'you@example.com', cancelThreshold: 0.25 };

// Helper builders
function wi(uid, title, s, e, rec) {
  return { workUid: uid, title: title, startIso: s, endIso: e, allDay: false,
           isRecurring: !!rec, occurrenceStartIso: rec ? s : null };
}
function cp(marker, title, s, e) {
  return { ref: 'ref:' + marker, url: marker, title: title, startIso: s, endIso: e,
           allDay: false, attendees: ['you@example.com'] };
}

// CREATE: work instance with no copy
var r1 = reconcile(
  [wi('A', 'Standup', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false)],
  [],
  OPTS);
eq(r1.toCreate.length, 1, 'create: one to create');
eq(r1.toCreate[0].marker, 'x-calsync://A', 'create: correct marker');
eq(r1.toCreate[0].title, 'Standup', 'create: title carried');
eq(r1.toUpdate.length, 0, 'create: none to update');
eq(r1.toCancel.length, 0, 'create: none to cancel');
eq(r1.guardTripped, false, 'create: guard not tripped');

// NO-OP: identical work + copy
var r2 = reconcile(
  [wi('A', 'Standup', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false)],
  [cp('x-calsync://A', 'Standup', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z')],
  OPTS);
eq(r2.toCreate.length, 0, 'noop: none created');
eq(r2.toUpdate.length, 0, 'noop: none updated');
eq(r2.toCancel.length, 0, 'noop: none cancelled');

// UPDATE: single event, title changed
var r3 = reconcile(
  [wi('A', 'Standup RENAMED', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false)],
  [cp('x-calsync://A', 'Standup', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z')],
  OPTS);
eq(r3.toUpdate.length, 1, 'update: one update on rename');
eq(r3.toUpdate[0].title, 'Standup RENAMED', 'update: new title');
eq(r3.toUpdate[0].ref, 'ref:x-calsync://A', 'update: carries copy ref');

// UPDATE: single event, time changed (marker stable -> update in place)
var r4 = reconcile(
  [wi('A', 'Standup', '2026-07-02T16:00:00Z', '2026-07-02T16:30:00Z', false)],
  [cp('x-calsync://A', 'Standup', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z')],
  OPTS);
eq(r4.toUpdate.length, 1, 'update: moved single event updates in place');
eq(r4.toUpdate[0].startIso, '2026-07-02T16:00:00Z', 'update: new start');

// RECURRING moved occurrence -> cancel old + create new (different markers)
// NOTE: diluted with 3 unaffected keep-alive pairs so the single cancel
// candidate (1 of 4 copies = 25%, not > 25%) doesn't spuriously trip the
// mass-cancel guard -- same trap class as the original buggy r6, just
// present here in the task spec's r5 instead. Without dilution, a lone
// copy that is 100% a cancel candidate always trips the guard.
var r5 = reconcile(
  [wi('B', 'Weekly', '2026-07-09T15:00:00Z', '2026-07-09T15:30:00Z', true),
   wi('K1', 'Keep', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false),
   wi('K2', 'Keep', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z', false),
   wi('K3', 'Keep', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z', false)],
  [cp('x-calsync://B/2026-07-02T15:00:00Z', 'Weekly', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z'),
   cp('x-calsync://K1', 'Keep', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z'),
   cp('x-calsync://K2', 'Keep', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z'),
   cp('x-calsync://K3', 'Keep', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z')],
  OPTS);
eq(r5.toCreate.length, 1, 'recurring move: create new occurrence');
eq(r5.toCreate[0].marker, 'x-calsync://B/2026-07-09T15:00:00Z', 'recurring move: new marker');
eq(r5.toCancel.length, 1, 'recurring move: cancel old occurrence');
eq(r5.toCancel[0].ref, 'ref:x-calsync://B/2026-07-02T15:00:00Z', 'recurring move: cancel ref');
eq(r5.guardTripped, false, 'recurring move: guard not tripped (1/4 = 25%)');

// CANCEL under threshold: 1 of 5 copies missing (20% <= 25%) -> cancel it
var r6 = reconcile(
  [wi('A', 'K', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false),
   wi('B', 'K', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z', false),
   wi('C', 'K', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z', false),
   wi('D', 'K', '2026-07-05T15:00:00Z', '2026-07-05T15:30:00Z', false)],
  [cp('x-calsync://A', 'K', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z'),
   cp('x-calsync://B', 'K', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z'),
   cp('x-calsync://C', 'K', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z'),
   cp('x-calsync://D', 'K', '2026-07-05T15:00:00Z', '2026-07-05T15:30:00Z'),
   cp('x-calsync://E', 'Gone', '2026-07-06T15:00:00Z', '2026-07-06T15:30:00Z')],
  OPTS);
eq(r6.toCancel.length, 1, 'cancel: one missing copy cancelled (1/5 = 20% <= 25%)');
eq(r6.toCancel[0].marker, 'x-calsync://E', 'cancel: correct marker');
eq(r6.guardTripped, false, 'cancel: guard not tripped at 20%');

// GUARD: 2 of 4 copies missing (50% > 25%) -> skip cancels, trip guard
var r7 = reconcile(
  [wi('A', 'Keep', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false),
   wi('B', 'Keep', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z', false)],
  [cp('x-calsync://A', 'Keep', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z'),
   cp('x-calsync://B', 'Keep', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z'),
   cp('x-calsync://C', 'Gone', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z'),
   cp('x-calsync://D', 'Gone', '2026-07-05T15:00:00Z', '2026-07-05T15:30:00Z')],
  OPTS);
eq(r7.guardTripped, true, 'guard: tripped at 50%');
eq(r7.toCancel.length, 0, 'guard: no cancels emitted when tripped');
eq(r7.summary.cancelled, 0, 'guard: summary cancelled is 0 when tripped');

// GUARD: empty copies never trips (division-by-zero safety)
var r8 = reconcile([wi('A','X','2026-07-02T15:00:00Z','2026-07-02T15:30:00Z',false)], [], OPTS);
eq(r8.guardTripped, false, 'guard: empty copies never trips');

// SUMMARY reflects the plan
var r9 = reconcile(
  [wi('A', 'New', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false),
   wi('B', 'Renamed', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z', false)],
  [cp('x-calsync://B', 'Old', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z')],
  OPTS);
eq(r9.summary, { created: 1, updated: 1, cancelled: 0 }, 'summary: counts reflect plan');

// THRESHOLD VALIDATION: NaN must not disable the guard (falls back to default 0.25)
var rNaN = reconcile(
  [wi('A', 'Keep', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z', false),
   wi('B', 'Keep', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z', false)],
  [cp('x-calsync://A', 'Keep', '2026-07-02T15:00:00Z', '2026-07-02T15:30:00Z'),
   cp('x-calsync://B', 'Keep', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z'),
   cp('x-calsync://C', 'Gone', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z'),
   cp('x-calsync://D', 'Gone', '2026-07-05T15:00:00Z', '2026-07-05T15:30:00Z')],
  { personalEmail: 'you@example.com', cancelThreshold: NaN });
eq(rNaN.guardTripped, true, 'NaN threshold falls back to default and still trips at 50%');

// attendeesWithinAllowed(attendees, personalEmail, organizerEmail)
// personalEmail must be present; every attendee must be personalEmail or organizerEmail; nothing else.
eq(attendeesWithinAllowed(['you@example.com'], 'you@example.com', ''), true, 'allowed: personal only, no organizer configured');
eq(attendeesWithinAllowed(['you@example.com', 'org@icloud.com'], 'you@example.com', 'org@icloud.com'), true, 'allowed: personal + organizer');
eq(attendeesWithinAllowed(['org@icloud.com', 'you@example.com'], 'you@example.com', 'org@icloud.com'), true, 'allowed: order-independent');
eq(attendeesWithinAllowed(['YOU@Example.com', 'ORG@icloud.com'], 'you@example.com', 'org@icloud.com'), true, 'allowed: case-insensitive');
eq(attendeesWithinAllowed(['you@example.com', 'boss@work.com'], 'you@example.com', 'org@icloud.com'), false, 'refused: a third-party coworker');
eq(attendeesWithinAllowed(['you@example.com', 'org@icloud.com'], 'you@example.com', ''), false, 'refused: organizer present but not configured');
eq(attendeesWithinAllowed(['org@icloud.com'], 'you@example.com', 'org@icloud.com'), false, 'refused: personal email absent');
eq(attendeesWithinAllowed([], 'you@example.com', 'org@icloud.com'), false, 'refused: no attendees');
eq(attendeesWithinAllowed(['you@example.com', 'org@icloud.com', 'boss@work.com'], 'you@example.com', 'org@icloud.com'), false, 'refused: personal+organizer+coworker');
eq(attendeesWithinAllowed(['you@example.com'], '', 'org@icloud.com'), false, 'refused: empty personalEmail fails closed');
eq(attendeesWithinAllowed([{ email: 'x' }, 'you@example.com'], 'you@example.com', 'org@icloud.com'), false, 'refused: non-string attendee fails closed');
eq(attendeesWithinAllowed(null, 'you@example.com', 'org@icloud.com'), false, 'refused: null attendees');

// containsEmail(emails, target) — normalized membership; used to skip work events the
// personal account is already invited to.
eq(containsEmail(['a@x.com', 'you@example.com'], 'you@example.com'), true, 'contains: present');
eq(containsEmail(['A@X.com', 'YOU@Example.com'], 'you@example.com'), true, 'contains: case-insensitive');
eq(containsEmail([' you@example.com '], 'you@example.com'), true, 'contains: trims whitespace');
eq(containsEmail(['boss@work.com'], 'you@example.com'), false, 'contains: absent');
eq(containsEmail([], 'you@example.com'), false, 'contains: empty list');
eq(containsEmail(['you@example.com'], ''), false, 'contains: empty target never matches');
eq(containsEmail(null, 'you@example.com'), false, 'contains: null list');
eq(containsEmail([{ email: 'x' }, 'you@example.com'], 'you@example.com'), true, 'contains: ignores non-string entries but still finds match');
eq(containsEmail([{ email: 'x' }], 'you@example.com'), false, 'contains: non-string entry does not match');

// Duplicate physical copies (same marker) are cleaned regardless of the mass-cancel guard.
function cpr(ref, marker, s, e) {
  return { ref: ref, url: marker, title: 'X', startIso: s, endIso: e, allDay: false, attendees: ['you@example.com'] };
}
var DS = '2026-07-02T15:00:00Z', DE = '2026-07-02T15:30:00Z';

// dup + matching work: canonical kept, duplicate cancelled (even though 1/2 > 25% guard ratio)
var dup1 = reconcile(
  [wi('A', 'X', DS, DE, false)],
  [cpr('ref1', 'x-calsync://A', DS, DE), cpr('ref2', 'x-calsync://A', DS, DE)],
  OPTS);
eq(dup1.toCreate.length, 0, 'dup+match: no create');
eq(dup1.toUpdate.length, 0, 'dup+match: no update');
eq(dup1.toCancel.length, 1, 'dup+match: duplicate cancelled despite guard ratio');
eq(dup1.toCancel[0].ref, 'ref2', 'dup+match: second copy (dup) cancelled, first kept');
eq(dup1.guardTripped, false, 'dup+match: guard not tripped (no source-gone cancels)');

// triple dup of a matched event: both extras cancelled, guard-exempt
var dup2 = reconcile(
  [wi('A', 'X', DS, DE, false)],
  [cpr('a0', 'x-calsync://A', DS, DE), cpr('a1', 'x-calsync://A', DS, DE), cpr('a2', 'x-calsync://A', DS, DE)],
  OPTS);
eq(dup2.toCancel.length, 2, 'triple dup: two extras cancelled');
eq(dup2.guardTripped, false, 'triple dup: guard not tripped (duplicates are exempt)');

// dup of a source-gone event: canonical (guarded) + duplicate (exempt) both cancelled, under threshold
var dup3 = reconcile(
  [wi('K1', 'X', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z', false),
   wi('K2', 'X', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z', false),
   wi('K3', 'X', '2026-07-05T15:00:00Z', '2026-07-05T15:30:00Z', false)],
  [cpr('k1', 'x-calsync://K1', '2026-07-03T15:00:00Z', '2026-07-03T15:30:00Z'),
   cpr('k2', 'x-calsync://K2', '2026-07-04T15:00:00Z', '2026-07-04T15:30:00Z'),
   cpr('k3', 'x-calsync://K3', '2026-07-05T15:00:00Z', '2026-07-05T15:30:00Z'),
   cpr('g1', 'x-calsync://GONE', DS, DE), cpr('g2', 'x-calsync://GONE', DS, DE)],
  OPTS);
eq(dup3.toCancel.length, 2, 'dup of source-gone: canonical + duplicate both cancelled');
eq(dup3.guardTripped, false, 'dup of source-gone: guard not tripped at 1/5 guarded');

// titleExcluded(title) — events whose title contains the 🚫 marker are opted out of sync.
eq(titleExcluded('Standup 🚫'), true, 'excluded: marker at end');
eq(titleExcluded('🚫'), true, 'excluded: marker only');
eq(titleExcluded('Plan 🚫 review'), true, 'excluded: marker in middle');
eq(titleExcluded('Standup'), false, 'not excluded: no marker');
eq(titleExcluded(''), false, 'not excluded: empty title');
eq(titleExcluded(null), false, 'not excluded: null title (no throw)');
eq(titleExcluded(123), false, 'not excluded: non-string (no throw)');

done();
