// CalSync JXA test harness.
//
// IMPORTANT: Every test file MUST end with done() -- it is the ONLY thing that
// sets the process exit code. A test file that prints FAIL: but forgets done()
// will exit 0, turning a red build green. Always call done() last.

ObjC.import('Foundation');
ObjC.import('stdlib');

function _readFile(path) {
  var s = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, $());
  var str = ObjC.unwrap(s);
  if (str === undefined || str === null) {
    console.log('CalSync test harness: could not read file: ' + path + ' (run tests from repo root)');
    $.exit(2);
  }
  return str;
}

// Direct eval at top level -> declarations become globals in the including file.
function include(path) { eval.call(null, _readFile(path)); }

function _deepEqual(a, b) {
  if (a === b) return true;
  if (a === null || b === null) return a === b;
  if (typeof a !== 'object' || typeof b !== 'object') return false;
  var aIsArr = Array.isArray(a), bIsArr = Array.isArray(b);
  if (aIsArr !== bIsArr) return false;
  if (aIsArr) {
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
      if (!_deepEqual(a[i], b[i])) return false;
    }
    return true;
  }
  var aKeys = Object.keys(a), bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) return false;
  for (var j = 0; j < aKeys.length; j++) {
    var k = aKeys[j];
    if (!Object.prototype.hasOwnProperty.call(b, k)) return false;
    if (!_deepEqual(a[k], b[k])) return false;
  }
  return true;
}

var _checks = 0, _fails = 0, _doneCalled = false;
function eq(actual, expected, msg) {
  _checks++;
  if (!_deepEqual(actual, expected)) {
    _fails++;
    console.log('FAIL: ' + msg + '\n   got:  ' + JSON.stringify(actual) + '\n   want: ' + JSON.stringify(expected));
  } else {
    console.log('ok: ' + msg);
  }
}
function ok(cond, msg) { eq(!!cond, true, msg); }
function done() {
  _doneCalled = true;
  console.log('\n' + _checks + ' checks, ' + _fails + ' failure(s)');
  $.exit(_fails > 0 ? 1 : 0);
}
