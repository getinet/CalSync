ObjC.import('EventKit');
ObjC.import('Foundation');

function nsDate(js) { return $.NSDate.dateWithTimeIntervalSince1970(js.getTime() / 1000); }
function toIso(ekDate) { return ObjC.unwrap(ekDate).toISOString(); } // EKEvent NSDate -> JS Date -> ISO

// Requests full calendar access, spinning the run loop until the async callback fires.
// Returns true if granted, false otherwise (logged).
var EK_AUTH_LEGACY_FULL = 3;  // authorized (pre-macOS 14)
var EK_AUTH_FULL = 5;         // fullAccess (macOS 14+)

function ensureCalendarAccess(store) {
  // authorizationStatusForEntityType returns a boxed value that stringifies to the
  // numeric status but does not === a JS number; coerce explicitly.
  var status = Number($.EKEventStore.authorizationStatusForEntityType($.EKEntityTypeEvent));
  if (status === EK_AUTH_LEGACY_FULL || status === EK_AUTH_FULL) return true;  // write-only (4) excluded
  var done = false, granted = false;
  var handler = function(g) { granted = g; done = true; };
  if (store.respondsToSelector($.NSSelectorFromString('requestFullAccessToEventsWithCompletion:'))) {
    store.requestFullAccessToEventsWithCompletion(handler);
  } else {
    store.requestAccessToEntityTypeCompletion($.EKEntityTypeEvent, handler);
  }
  var spins = 0;
  while (!done && spins < 600) { // up to ~60s
    $.NSRunLoop.currentRunLoop.runModeBeforeDate($.NSDefaultRunLoopMode, $.NSDate.dateWithTimeIntervalSinceNow(0.1));
    spins++;
  }
  if (!granted) logLine('CalSync: full calendar access not granted (status ' + status + ')');
  return granted;
}

// Returns array of workInstance, or null if access denied or calendar not found.
function getWorkInstances(calendarName, startDate, endDate, calendarAccount, personalEmail) {
  var store = $.EKEventStore.alloc.init;
  if (!ensureCalendarAccess(store)) return null;

  // Match by title, and — when configured — also by account (EKSource title) to
  // disambiguate calendars that share a name across accounts (e.g. two "Calendar"s).
  var wantAccount = (typeof calendarAccount === 'string' && calendarAccount.trim() !== '') ? calendarAccount : null;
  var allCals = store.calendarsForEntityType($.EKEntityTypeEvent);
  var matches = [], n = allCals.count;
  for (var i = 0; i < n; i++) {
    var c = allCals.objectAtIndex(i);
    if (ObjC.unwrap(c.title) !== calendarName) continue;
    if (wantAccount) {
      var src = c.source;
      var srcTitle = src.isNil() ? '' : ObjC.unwrap(src.title);
      if (srcTitle !== wantAccount) continue;
    }
    matches.push(c);
  }
  if (matches.length === 0) {
    logLine('CalSync: work calendar not found: ' + calendarName + (wantAccount ? ' (account "' + wantAccount + '")' : ''));
    return null;
  }
  if (matches.length > 1) {
    logLine('CalSync: ambiguous work calendar — ' + matches.length + ' calendars match "' + calendarName + '"' +
            (wantAccount ? ' (account "' + wantAccount + '")' : '') + '; set workCalendarAccount to disambiguate; refusing to guess');
    return null;
  }
  var target = matches[0];

  var predicate = store.predicateForEventsWithStartDateEndDateCalendars(
    nsDate(startDate), nsDate(endDate), $.NSArray.arrayWithObject(target));
  var evs = store.eventsMatchingPredicate(predicate); // expanded occurrences, exceptions applied

  var out = [], m = evs.count;
  for (var j = 0; j < m; j++) {
    var ev = evs.objectAtIndex(j);
    var uid = ObjC.unwrap(ev.calendarItemExternalIdentifier);
    var title = ObjC.unwrap(ev.title);
    if (!uid) { logLine('CalSync: skipping event with no external identifier: ' + title); continue; }

    // Manual opt-out: a title containing the exclusion marker is never synced.
    if (titleExcluded(title)) {
      logLine('CalSync: skipping event — title contains exclusion marker: ' + title);
      continue;
    }

    // Skip events the personal account is already invited to directly — no need to
    // mirror what the user already sees on their personal calendar. Source attendee
    // emails are read ONLY for this decision and never stored or copied, so no
    // third-party address enters the pipeline.
    if (personalEmail) {
      var srcEmails = [];
      try {
        var atts = ev.attendees;
        if (atts && !atts.isNil()) {
          var ac = atts.count;
          for (var k = 0; k < ac; k++) {
            var purl = atts.objectAtIndex(k).URL;
            if (purl && !purl.isNil()) {
              var spec = ObjC.unwrap(purl.resourceSpecifier); // "email@host" from mailto:
              if (spec) srcEmails.push(spec);
            }
          }
        }
      } catch (e) { srcEmails = []; }
      if (containsEmail(srcEmails, personalEmail)) {
        logLine('CalSync: skipping event — personal account already a guest: ' + title);
        continue;
      }
    }

    var isRecurring = !!ev.hasRecurrenceRules;
    var startIso = toIso(ev.startDate);
    // all-day events carry EventKit's raw instants (local-midnight boundaries) verbatim; the Writer copies them as-is
    out.push({
      workUid: uid,
      title: title,
      startIso: startIso,
      endIso: toIso(ev.endDate),
      allDay: !!ev.isAllDay,
      isRecurring: isRecurring,
      occurrenceStartIso: isRecurring ? (ev.occurrenceDate.isNil() ? startIso : toIso(ev.occurrenceDate)) : null
    });
  }
  return out;
}

// ---- Logging ----
function calsyncDir() {
  var home = ObjC.unwrap($.NSHomeDirectory());
  return home + '/.calsync';
}

// The sole diagnostic channel. Echoes to stdout (so manual runs show output and
// launchd captures it via stderr) AND appends to the log file. Fail-safe: a
// logging failure must never crash a run that would otherwise proceed.
function logLine(line) {
  var entry = new Date().toISOString() + ' ' + line;
  try { console.log(entry); } catch (e) {}
  try {
    var dir = calsyncDir();
    var fm = $.NSFileManager.defaultManager;
    fm.createDirectoryAtPathWithIntermediateDirectoriesAttributesError(dir, true, $(), $());
    var path = dir + '/calsync.log';
    var data = entry + '\n';
    if (!fm.fileExistsAtPath(path)) {
      $(data).writeToFileAtomicallyEncodingError($(path), true, $.NSUTF8StringEncoding, $());
    } else {
      var fh = $.NSFileHandle.fileHandleForWritingAtPath(path);
      fh.seekToEndOfFile;
      fh.writeData($(data).dataUsingEncoding($.NSUTF8StringEncoding));
      fh.closeFile;
    }
  } catch (e) {}
}

// ---- Reading existing copies from the dedicated calendar (Calendar.app) ----
function isoToDate(iso) { return new Date(iso); }

// Returns array of copy objects for CalSync-authored events in the dedicated calendar within window.
function getExistingCopies(dedicatedCalendarName, startDate, endDate) {
  var Cal = Application('Calendar');
  var cals = Cal.calendars.whose({ name: dedicatedCalendarName })();
  if (cals.length === 0) return [];
  var cal = cals[0];
  // OVERLAP window (endDate >= start AND startDate <= end), matching the EventKit reader's
  // semantics. A plain startDate-in-window filter misses copies that started earlier today
  // but are still ongoing (notably all-day events), which made reconcile fail to find the
  // existing copy and re-create it every run.
  var evs = cal.events.whose({ _and: [ { endDate: { '>=': startDate } }, { startDate: { '<=': endDate } } ] })();
  var out = [];
  for (var i = 0; i < evs.length; i++) {
    var ev = evs[i];
    // A per-event failure must not abort reading the rest — skip just this event and log it.
    try {
      var url = ev.url() || '';
      if (!parseMarker(url)) continue; // not a CalSync copy — skip silently (legitimately not ours)
      var attendees = [];
      var atts = ev.attendees();
      for (var a = 0; a < atts.length; a++) { attendees.push(atts[a].email()); }
      out.push({
        ref: ev, url: url, title: ev.summary(),
        startIso: ev.startDate().toISOString(), // JXA startDate() is already a JS Date
        endIso: ev.endDate().toISOString(),
        allDay: !!ev.alldayEvent(), attendees: attendees
      });
    } catch (e) {
      logLine('WARN skipped unreadable copy in dedicated calendar: ' + e);
      continue;
    }
  }
  return out;
}

// ---- Writing ----
// Creates a copy in the dedicated calendar. Enforces the attendee guardrail BOTH
// before creation (refuse on bad personal email) and after (read-back assert that
// attendees are only personalEmail + the calendar's organizer, never a third party).
// Returns true on success, false if refused/failed (already logged).
function applyCreate(dedicatedCal, item, personalEmail, organizerEmail) {
  // Primary guardrail: never proceed unless the intended sole attendee we add is valid.
  if (!isSingleValidAttendee([personalEmail], personalEmail)) {
    logLine('REFUSED create (invalid personalEmail) marker=' + item.marker);
    return false;
  }
  var Cal = Application('Calendar');
  var ev = Cal.Event({
    summary: item.title,
    startDate: isoToDate(item.startIso),
    endDate: isoToDate(item.endIso),
    alldayEvent: item.allDay,
    url: item.marker
  });
  var pushed = false;
  try {
    dedicatedCal.events.push(ev);
    pushed = true;
    ev.attendees.push(Cal.Attendee({ email: personalEmail }));

    // Secondary guardrail: read back actual attendees. iCloud auto-adds the calendar's
    // owner (organizer) as a participant, so the allowed set is {personalEmail, organizerEmail}.
    // Any THIRD address (e.g. a coworker) fails closed → delete + refuse. Safe by construction:
    // the only address we ever explicitly add is personalEmail, so even a pre-read-back invite
    // dispatch can only reach the user.
    var emails = [];
    var atts = ev.attendees();
    for (var i = 0; i < atts.length; i++) emails.push(atts[i].email());
    if (!attendeesWithinAllowed(emails, personalEmail, organizerEmail)) {
      logLine('REFUSED create (attendee guardrail) marker=' + item.marker + ' attendees=' + JSON.stringify(emails));
      ev.delete();
      return false;
    }
    return true;
  } catch (e) {
    // Clean up a half-created event so it can't get stuck failing the guardrail forever.
    logLine('ERROR create marker=' + item.marker + ' (cleaning up partial event): ' + e);
    if (pushed) { try { ev.delete(); } catch (e2) {} }
    return false;
  }
}

// Updates an existing copy in place. Asserts the guardrail BEFORE mutating so we
// never emit an update notification for a copy whose attendee list contains a
// third party (only personalEmail + the organizer are allowed).
function applyUpdate(item, personalEmail, organizerEmail) {
  var ev = item.ref;
  // Guardrail FIRST: read the existing attendees and refuse before mutating anything.
  var emails = [];
  try { var atts = ev.attendees(); for (var i = 0; i < atts.length; i++) emails.push(atts[i].email()); } catch (e) {}
  if (!attendeesWithinAllowed(emails, personalEmail, organizerEmail)) {
    logLine('REFUSED update (attendee guardrail) marker=' + item.marker + ' attendees=' + JSON.stringify(emails));
    return false;
  }
  ev.summary = item.title;
  ev.startDate = isoToDate(item.startIso);
  ev.endDate = isoToDate(item.endIso);
  ev.alldayEvent = item.allDay;
  return true;
}

function applyCancel(item) {
  item.ref.delete();  // Calendar.app sends the cancellation to the attendee
  return true;
}
