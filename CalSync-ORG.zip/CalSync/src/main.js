function loadConfig() {
  var home = ObjC.unwrap($.NSHomeDirectory());
  var path = home + '/.calsync/config.json';
  var s = $.NSString.stringWithContentsOfFileEncodingError($(path), $.NSUTF8StringEncoding, $());
  if (s.isNil()) throw new Error('Missing config at ' + path);
  var cfg;
  try { cfg = JSON.parse(ObjC.unwrap(s)); }
  catch (e) { throw new Error('Invalid JSON in ' + path + ': ' + e); }
  var required = ['workCalendarName', 'dedicatedCalendarName', 'personalEmail'];
  for (var i = 0; i < required.length; i++) {
    var v = cfg[required[i]];
    if (typeof v !== 'string' || v.trim() === '') {
      throw new Error('Config missing/empty required field: ' + required[i]);
    }
  }
  if (cfg.windowDays !== undefined) {
    var wd = cfg.windowDays;
    if (typeof wd !== 'number' || !isFinite(wd) || wd <= 0) {
      throw new Error('Config windowDays must be a positive number');
    }
  }
  return cfg;
}

function hasFlag(name) {
  // NOTE: ObjC.unwrap on the NSArray is shallow — elements stay as ObjC string
  // refs, so String(el) yields "[id ...]" and never matches. Unwrap each element.
  var argv = $.NSProcessInfo.processInfo.arguments;
  var n = argv.count;
  for (var i = 0; i < n; i++) {
    if (ObjC.unwrap(argv.objectAtIndex(i)) === name) return true;
  }
  return false;
}

// NOTE: must NOT be named `run` — osascript auto-invokes a top-level `run`
// handler, which combined with the explicit call below would execute twice.
function runCalSync() {
  var dryRun = hasFlag('--dry-run');

  var cfg;
  try { cfg = loadConfig(); }
  catch (e) { logLine('ABORT config error: ' + e); return; }

  var now = new Date();
  var end = new Date(now.getTime() + (cfg.windowDays || 30) * 864e5);

  try {
    var work = getWorkInstances(cfg.workCalendarName, now, end, cfg.workCalendarAccount, cfg.personalEmail);
    if (work === null) {
      logLine('ABORT reader returned null (work calendar not found or access denied): ' + cfg.workCalendarName);
      return;
    }

    var copies = getExistingCopies(cfg.dedicatedCalendarName, now, end);
    var plan = reconcile(work, copies, { personalEmail: cfg.personalEmail, cancelThreshold: cfg.cancelThreshold });

    var Cal = Application('Calendar');
    var dedCals = Cal.calendars.whose({ name: cfg.dedicatedCalendarName })();
    var dedFound = dedCals.length > 0;

    if (dryRun) {
      logLine('DRYRUN plan create=' + plan.toCreate.length + ' update=' + plan.toUpdate.length +
              ' cancel=' + plan.toCancel.length + ' guard=' + (plan.guardTripped ? 'tripped' : 'ok') +
              ' dedicatedCalendar=' + (dedFound ? 'found' : 'MISSING'));
      return;
    }

    if (!dedFound) { logLine('ABORT dedicated calendar not found: ' + cfg.dedicatedCalendarName); return; }
    var dedicatedCal = dedCals[0];

    var created = 0, updated = 0, cancelled = 0, failed = 0, i;
    for (i = 0; i < plan.toCreate.length; i++) {
      try { if (applyCreate(dedicatedCal, plan.toCreate[i], cfg.personalEmail, cfg.organizerEmail)) created++; }
      catch (e) { failed++; logLine('ERROR create marker=' + plan.toCreate[i].marker + ': ' + e); }
    }
    for (i = 0; i < plan.toUpdate.length; i++) {
      try { if (applyUpdate(plan.toUpdate[i], cfg.personalEmail, cfg.organizerEmail)) updated++; }
      catch (e) { failed++; logLine('ERROR update marker=' + plan.toUpdate[i].marker + ': ' + e); }
    }
    for (i = 0; i < plan.toCancel.length; i++) {
      try { if (applyCancel(plan.toCancel[i])) cancelled++; }
      catch (e) { failed++; logLine('ERROR cancel marker=' + plan.toCancel[i].marker + ': ' + e); }
    }

    logLine('RUN created=' + created + ' updated=' + updated + ' cancelled=' + cancelled +
            ' failed=' + failed + ' guard=' + (plan.guardTripped ? 'tripped' : 'ok'));
  } catch (e) {
    logLine('ABORT unexpected error: ' + e);
    return;
  }
}

runCalSync();
