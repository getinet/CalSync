var CALSYNC_SCHEME = 'x-calsync://';

// A work event whose title contains this marker is opted out of syncing.
var EXCLUDE_MARKER = '🚫';
function titleExcluded(title) {
  return typeof title === 'string' && title.indexOf(EXCLUDE_MARKER) !== -1;
}

function encodeMarker(workUid, occurrenceStartIso, isRecurring) {
  var uid = encodeURIComponent(workUid);
  if (isRecurring && occurrenceStartIso) {
    return CALSYNC_SCHEME + uid + '/' + occurrenceStartIso;
  }
  return CALSYNC_SCHEME + uid;
}

function safeDecode(s) {
  try { return decodeURIComponent(s); } catch (e) { return null; }
}

function parseMarker(url) {
  if (!url || url.indexOf(CALSYNC_SCHEME) !== 0) return null;
  var rest = url.slice(CALSYNC_SCHEME.length);
  var slash = rest.lastIndexOf('/');
  var uidPart = (slash === -1) ? rest : rest.slice(0, slash);
  var workUid = safeDecode(uidPart);
  if (workUid === null) return null;
  return (slash === -1)
    ? { workUid: workUid, occurrenceStartIso: null }
    : { workUid: workUid, occurrenceStartIso: rest.slice(slash + 1) };
}

function normalizeEmail(e) { return (typeof e === 'string' ? e : '').trim().toLowerCase(); }

// Safety-critical guardrail: must fail closed. Both sides must be genuinely
// non-empty strings; an empty/undefined personalEmail or non-string attendee
// must never pass.
function isSingleValidAttendee(attendees, personalEmail) {
  var pe = normalizeEmail(personalEmail);
  if (!pe || !attendees || attendees.length !== 1) return false;
  return normalizeEmail(attendees[0]) === pe;
}

// Safety-critical guardrail for the post-creation read-back. iCloud auto-adds the
// mirror calendar's owner (the organizer) as a second participant when any attendee
// is added, so the attendee list legitimately contains {personalEmail, organizerEmail}.
// Passes iff personalEmail is present AND every attendee is either personalEmail or the
// configured organizerEmail — any third-party address (e.g. a coworker) fails closed.
// Must fail closed on empty personalEmail or non-string attendees.
function attendeesWithinAllowed(attendees, personalEmail, organizerEmail) {
  var pe = normalizeEmail(personalEmail);
  if (!pe || !attendees || attendees.length === 0) return false;
  var oe = normalizeEmail(organizerEmail); // may be '' when no organizer is configured
  var sawPersonal = false;
  for (var i = 0; i < attendees.length; i++) {
    var a = normalizeEmail(attendees[i]);
    if (a === pe) { sawPersonal = true; continue; }
    if (oe && a === oe) continue;
    return false; // any address that is neither the personal nor the organizer
  }
  return sawPersonal;
}

// Normalized membership test. Used to skip work events whose guest list already
// includes the personal account (the user is invited directly, so no mirror needed).
function containsEmail(emails, target) {
  var t = normalizeEmail(target);
  if (!t || !emails) return false;
  for (var i = 0; i < emails.length; i++) {
    if (normalizeEmail(emails[i]) === t) return true;
  }
  return false;
}

function markerFor(workInstance) {
  return encodeMarker(workInstance.workUid, workInstance.occurrenceStartIso, workInstance.isRecurring);
}

function fieldsDiffer(workInstance, copy) {
  return workInstance.title !== copy.title
      || workInstance.startIso !== copy.startIso
      || workInstance.endIso !== copy.endIso
      || !!workInstance.allDay !== !!copy.allDay;
}

function reconcile(workInstances, copies, opts) {
  var threshold = 0.25;
  if (opts && typeof opts.cancelThreshold === 'number' && isFinite(opts.cancelThreshold) && opts.cancelThreshold >= 0 && opts.cancelThreshold <= 1) {
    threshold = opts.cancelThreshold;
  }

  var workByMarker = Object.create(null);
  for (var i = 0; i < workInstances.length; i++) {
    workByMarker[markerFor(workInstances[i])] = workInstances[i];
  }
  // Build the canonical copy per marker (first seen wins). Extra physical copies that
  // share a marker are redundant duplicates and are always removed — they are provably
  // safe to cancel and thus EXEMPT from the mass-cancel guard (which only protects
  // against a bad/partial work-calendar read making real events look "gone").
  var copyByMarker = Object.create(null);
  var duplicateCancels = [];
  for (var j = 0; j < copies.length; j++) {
    // a copy's url field stores its encoded marker (self-describing copies — see design doc Identity section)
    var mk = copies[j].url;
    if (copyByMarker[mk]) {
      duplicateCancels.push({ ref: copies[j].ref, marker: mk });
    } else {
      copyByMarker[mk] = copies[j];
    }
  }

  var toCreate = [], toUpdate = [], guardedCancels = [];

  for (var m in workByMarker) {
    var w = workByMarker[m];
    var existing = copyByMarker[m];
    if (!existing) {
      toCreate.push({ marker: m, title: w.title, startIso: w.startIso, endIso: w.endIso, allDay: !!w.allDay });
    } else if (fieldsDiffer(w, existing)) {
      toUpdate.push({ ref: existing.ref, marker: m, title: w.title, startIso: w.startIso, endIso: w.endIso, allDay: !!w.allDay });
    }
  }

  // Canonical copies whose source event is gone — subject to the mass-cancel guard.
  for (var c in copyByMarker) {
    if (!workByMarker[c]) {
      guardedCancels.push({ ref: copyByMarker[c].ref, marker: c });
    }
  }

  var guardTripped = false;
  var cancels = guardedCancels;
  if (copies.length > 0 && (guardedCancels.length / copies.length) > threshold) {
    guardTripped = true;
    cancels = [];
  }
  var toCancel = cancels.concat(duplicateCancels);

  return {
    toCreate: toCreate,
    toUpdate: toUpdate,
    toCancel: toCancel,
    guardTripped: guardTripped,
    summary: { created: toCreate.length, updated: toUpdate.length, cancelled: toCancel.length }
  };
}
